Language: EN
============

## File: EN/test.cupt
* Sentences: 3965
* Tokens: 71002
* Total VMWEs: 501
  * `IAV`: 44
  * `LVC.cause`: 36
  * `LVC.full`: 166
  * `MVC`: 4
  * `VID`: 79
  * `VPC.full`: 146
  * `VPC.semi`: 26

