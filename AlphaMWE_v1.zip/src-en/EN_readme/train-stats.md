Language: EN
============

## File: EN/train.cupt
* Sentences: 3471
* Tokens: 53201
* Total VMWEs: 331
  * `IAV`: 16
  * `LVC.cause`: 7
  * `LVC.full`: 78
  * `VID`: 60
  * `VPC.full`: 151
  * `VPC.semi`: 19

